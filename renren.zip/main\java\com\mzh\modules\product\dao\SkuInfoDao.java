package com.mzh.modules.product.dao;

import com.mzh.modules.product.entity.SkuInfoEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * sku信息
 * 
 * @author ZhihaoMeng
 * @email 717333759@qq.com
 * @date 2024-05-14 11:17:24
 */
@Mapper
public interface SkuInfoDao extends BaseMapper<SkuInfoEntity> {
	
}
